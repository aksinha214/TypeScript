interface User {
    readonly dbId:number,
    email:string,
    userId: number,
    googleId?:string,
    // startTrail: () => string
    startTrail(): string,
    getCoupon(couponname: string, value: number): number
}

interface User {
    githubToken: string
}

interface Admin extends User {
    role:"admin" | "ta" | "learner"
}

const ak : Admin = {
    dbId: 22,
    role:"admin",
    githubToken:"github",
    email:"ak@gmail.com",
    userId:3332,
    startTrail:()=>{
    return "trail started"
    },
    getCoupon: (name: "ak214", off:10) => {
        return 10
    }
}

ak.email = "ak@gmail.com"
