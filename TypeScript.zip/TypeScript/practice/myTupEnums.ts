// const user: (string | number)[] = [1, "ak"]
let tUser: [string, number, boolean] 

tUser = ["ak",232,true]


let rgb: [number,number,number] = [255,212,112]

type User = [number,string]

const newUser: User = [112,"example@gmail.com"]

newUser[1]="ak.com"






export{}