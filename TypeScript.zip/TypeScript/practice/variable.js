"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var greetings = "AKK";
var mynum = 6;
greetings.toLowerCase();
console.log(greetings);
