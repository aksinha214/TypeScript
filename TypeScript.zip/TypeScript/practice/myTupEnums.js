"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// const user: (string | number)[] = [1, "ak"]
var tUser;
tUser = ["ak", 232, true];
var rgb = [255, 212, 112];
var newUser = [112, "example@gmail.com"];
newUser[1] = "ak.com";
