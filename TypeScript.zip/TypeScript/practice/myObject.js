"use strict";
// const User = {
//     name:'Akk',
//     email:"akk@gmail.com",
//     isActive: true
// }
Object.defineProperty(exports, "__esModule", { value: true });
var myUser = {
    _id: "1234",
    name: "a",
    email: "a@gmail.com",
    isActive: false
};
myUser.email = 'a@gmail.com';
