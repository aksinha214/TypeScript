// const User = {
//     name:'Akk',
//     email:"akk@gmail.com",
//     isActive: true
// }

// function createUser({name: string,isPaid: boolean}){}

// let newUser = {name:'Akk',isPaid:false,email:"akk@gmail.com"}

// createUser(newUser)

// function createCourse():{name: string,price:number}{
//     return {name: "Typescript",price:499}
// }




// type User = {
//     name: string;
//     email:string;
//     isActive: boolean
// }



// function createUser(user: User): User{
//     return {name: "",email: "",isActive: true}
// }

// createUser({name: "",email: "",isActive: true})


type User = {
    readonly _id: string
    name: string
    email: string
    isActive: boolean
    credcardDetails?: number
}

let myUser : User = {
    _id:"1234",
    name:"a",
    email: "a@gmail.com",
    isActive: false

}


type cardNumber = {
    cardnumber: string
}

type cardDate = {
    cardDate: string
}

type cardDetails = cardNumber & cardDate & {
    cvv: number
}


myUser.email = 'a@gmail.com'


export{}