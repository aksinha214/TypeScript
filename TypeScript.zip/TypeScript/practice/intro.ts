let user = { name:"Ak",age:10}

console.log(user.name);


console.log("Akk");
