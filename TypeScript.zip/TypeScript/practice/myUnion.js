var score = 33;
score = 44;
score = "44";
var ak = { name: "Akk", id: 323 };
ak = { username: "AS", id: 323 };
// function getDbId(id: number | string){
//     //making some API calls
//     console.log(`DB id is: ${id}`);
// }
getDbId(3);
getDbId("3");
function getDbId(id) {
    if (typeof id === "string") {
        id.toLowerCase();
    }
}
//array
var data = [1, 2, 3, 4];
var data2 = ["1", "2", "3", "4"];
// const data3: any[] = ["1","2","3",4,true]
var data4 = ["1", "2", "3", 4, true];
// let pi:3.14 = 3.14
var seatAllotment;
seatAllotment = "aisle";
