var ak = {
    dbId: 22,
    role: "admin",
    githubToken: "github",
    email: "ak@gmail.com",
    userId: 3332,
    startTrail: function () {
        return "trail started";
    },
    getCoupon: function (name, off) {
        return 10;
    }
};
ak.email = "ak@gmail.com";
