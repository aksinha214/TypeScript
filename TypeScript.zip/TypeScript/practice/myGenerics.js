var score = [];
var names = [];
function identityOne(val) {
    return val;
}
function identitytwo(val) {
    return val;
}
function identityThree(val) {
    return val;
}
// identityThree(3)
function identityFour(val) {
    return val;
}
// identityFour<Bottle>({})
function getsearchProducts(products) {
    //do some database operation
    var myIndex = 3;
    return products[myIndex];
}
var getmoreSearchProducts = function (products) {
    //do some database operation
    var myIndex = 4;
    return products[myIndex];
};
function anotherFuntion(valOne, valTwo) {
    return {
        valOne: valOne,
        valTwo: valTwo
    };
}
var Sellabe = /** @class */ (function () {
    function Sellabe() {
        this.cart = [];
    }
    Sellabe.prototype.addToCart = function (products) {
        this.cart.push(products);
    };
    return Sellabe;
}());
