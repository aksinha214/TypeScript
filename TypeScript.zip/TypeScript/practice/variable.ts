let greetings: string = "AKK";

greetings.toLowerCase()
console.log(greetings)

//number
let userID: number = 32323.3343

userID.toFixed()
//boolean
let isLogIn: boolean = false

//any
let hero;

function getHero(){
    return "thor"
}

hero: getHero()

export{}

