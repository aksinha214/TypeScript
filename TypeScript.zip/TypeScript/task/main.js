var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
$(document).ready(function () {
    'use strict';
    // Initialize dataStorage array from localStorage
    var dataStorage = JSON.parse(localStorage.getItem('formData') || '[]');
    var editIndex = null;
    renderTable();
    $('#multiInputForm').on('submit', function (event) {
        var _a, _b;
        event.preventDefault();
        var formElement = this;
        // Check form validity
        var isFormValid = formElement.checkValidity();
        var isProfessionValid = validateProfession();
        if (!isFormValid || !isProfessionValid) {
            event.stopPropagation();
            $(formElement).addClass('was-validated');
            return; // Exit if validation fails
        }
        var formData = new FormData(formElement);
        var jsonObject = {};
        var name = (_a = formData.get('name')) === null || _a === void 0 ? void 0 : _a.toString().trim().toLowerCase();
        var email = (_b = formData.get('email')) === null || _b === void 0 ? void 0 : _b.toString().trim().toLowerCase();
        // Check for duplicate name and email
        var isDuplicate = dataStorage.some(function (data, index) {
            return (data.name.toLowerCase() === name || data.email.toLowerCase() === email) && index !== editIndex;
        });
        if (isDuplicate) {
            alert(dataStorage.some(function (data) { return data.name.toLowerCase() === name; }) ? "The user with this NAME already exists." : "The user with this EMAIL already exists.");
            return;
        }
        var files = [];
        var fileInput = formData.get('file');
        // Check if a file is selected and valid
        if (fileInput && fileInput.size > 0) {
            if (!validateFile(fileInput)) {
                return; // If validation fails, stop processing
            }
            var reader = new FileReader();
            reader.onload = function (e) {
                var _a;
                files.push({ fileName: fileInput.name, fileData: (_a = e.target) === null || _a === void 0 ? void 0 : _a.result });
                collectFormData(formData, jsonObject, files);
            };
            reader.readAsDataURL(fileInput);
        }
        else {
            // No file selected or file input empty, continue without file data
            collectFormData(formData, jsonObject, files);
        }
    });
    function collectFormData(formData, jsonObject, files) {
        formData.forEach(function (value, key) {
            if (key !== 'file') {
                if (key === 'profession') {
                    if (!jsonObject[key]) {
                        jsonObject[key] = [];
                    }
                    jsonObject[key].push(value);
                }
                else {
                    jsonObject[key] = value;
                }
            }
        });
        // Initialize files as an empty array if it's undefined
        if (editIndex !== null && dataStorage[editIndex]) {
            jsonObject['files'] = dataStorage[editIndex].files ? __spreadArray(__spreadArray([], dataStorage[editIndex].files, true), files, true) : files;
        }
        else {
            jsonObject['files'] = files;
        }
        storeData(jsonObject);
    }
    function storeData(data) {
        if (editIndex !== null) {
            dataStorage[editIndex] = data;
            editIndex = null;
        }
        else {
            dataStorage.push(data);
        }
        try {
            localStorage.setItem('formData', JSON.stringify(dataStorage));
            renderTable();
            var formElement = $('#multiInputForm')[0];
            $(formElement).removeClass('was-validated');
            formElement.reset(); // Correctly reset the form  
        }
        catch (err) {
            console.error("Error occurred while saving data: ", err);
        }
    }
    function renderTable() {
        var dataTable = $('#dataTable');
        dataTable.empty();
        dataStorage.forEach(function (data, index) {
            var row = $('<tr>');
            var actions = $('<td>');
            var editButton = $('<button>').text('Edit').addClass('btn btn-warning btn-sm').on('click', function () {
                editData(index);
            });
            var deleteButton = $('<button>').text('Delete').addClass('btn btn-danger btn-sm').on('click', function () {
                deleteData(index);
            });
            actions.append(editButton).append(deleteButton);
            row.append(actions);
            row.append($('<td>').text(data.name));
            row.append($('<td>').text(data.email));
            row.append($('<td>').text(data.password));
            row.append($('<td>').text(data.number));
            row.append($('<td>').text(data.date));
            row.append($('<td>').text(data.color));
            row.append($('<td>').text(data.gender));
            row.append($('<td>').text(Array.isArray(data.profession) ? data.profession.join(', ') : data.profession));
            row.append($('<td>').text(data.country));
            row.append($('<td>').text(data.textarea));
            // Ensure data.files is an array before mapping
            var fileLinks = (data.files || []).map(function (file) { return "<a href=\"".concat(file.fileData, "\" download=\"").concat(file.fileName, "\">").concat(file.fileName, "</a>"); }).join('<br>');
            row.append($('<td>').html(fileLinks));
            dataTable.append(row);
        });
    }
    function editData(index) {
        var data = dataStorage[index];
        editIndex = index;
        $('#name').val(data.name);
        $('#email').val(data.email);
        $('#password').val(data.password);
        $('#number').val(data.number);
        $('#date').val(data.date);
        $('#color').val(data.color);
        $('input[name="gender"][value="' + data.gender + '"]').prop('checked', true);
        $('input[name="profession"]').prop('checked', false);
        if (Array.isArray(data.profession)) {
            data.profession.forEach(function (prof) {
                $('input[name="profession"][value="' + prof + '"]').prop('checked', true);
            });
        }
        else {
            $('input[name="profession"][value="' + data.profession + '"]').prop('checked', true);
        }
        $('#country').val(data.country);
        $('#textarea').val(data.textarea);
        if (data.files && data.files.length > 0) {
            var fileNames = data.files.map(function (file) { return file.fileName; }).join(', ');
            $('#file').text("Current files: ".concat(fileNames));
        }
        else {
            $('#file').text('No files uploaded.');
        }
    }
    function deleteData(index) {
        dataStorage.splice(index, 1);
        localStorage.setItem('formData', JSON.stringify(dataStorage));
        renderTable();
    }
    function validateProfession() {
        if ($('input[name="profession"]:checked').length === 0) {
            $('input[name="profession"]').each(function () {
                $(this).addClass('is-invalid').css('color', 'red');
            });
            alert("Please select at least one profession.");
            return false;
        }
        else {
            $('input[name="profession"]').each(function () {
                $(this).removeClass('is-invalid');
            });
            return true;
        }
    }
    function validateFile(file) {
        var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
        var maxSize = 5 * 1024 * 1024; // Maximum file size (5MB)
        var isValidType = false;
        for (var _i = 0, allowedTypes_1 = allowedTypes; _i < allowedTypes_1.length; _i++) {
            var type = allowedTypes_1[_i];
            if (file.type === type) {
                isValidType = true;
                break;
            }
        }
        if (!isValidType) {
            alert('Invalid file type. Only JPG, JPEG, PNG, and PDF files are allowed.');
            return false;
        }
        if (file.size > maxSize) {
            alert('File size exceeds the maximum limit of 5MB.');
            return false;
        }
        // if (file.name === file.name) {
        //     alert('This file already exists in the current entry.');
        //     return false;
        // }
        return true;
    }
});
